"""Adds the Android settings PING needs (run after `flutter create`)."""
import pathlib
import re
import shutil
import sys

root = pathlib.Path('android')
if not root.exists():
    sys.exit('android/ folder not found - run flutter create first')

# ---------- manifest: permissions, receivers, app name
mf = root / 'app/src/main/AndroidManifest.xml'
s = mf.read_text()
perms = [
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.RECEIVE_BOOT_COMPLETED',
    'android.permission.USE_EXACT_ALARM',
    'android.permission.SCHEDULE_EXACT_ALARM',
    'android.permission.VIBRATE',
]
add = ''.join('    <uses-permission android:name="%s"/>\n' % p for p in perms if p not in s)
if '<application' not in s:
    sys.exit('manifest has no <application> tag')
s = s.replace('<application', add + '    <application', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="PING"', s, count=1)

receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
'''
if 'ScheduledNotificationReceiver' not in s:
    s = s.replace('</application>', receivers + '    </application>', 1)

view_https = '''        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
'''
if '</queries>' in s and 'android:scheme="https"' not in s:
    s = s.replace('</queries>', view_https + '    </queries>', 1)
mf.write_text(s)
print('manifest patched')

# ---------- gradle: core library desugaring (needed by flutter_local_notifications)
patched = False
for name, kts in (('app/build.gradle', False), ('app/build.gradle.kts', True)):
    f = root / name
    if not f.exists():
        continue
    g = f.read_text()
    if 'coreLibraryDesugaring' in g:
        patched = True
        continue
    flag = 'isCoreLibraryDesugaringEnabled = true' if kts else 'coreLibraryDesugaringEnabled true'
    dep = 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")' if kts else \
        "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'"
    if not re.search(r'compileOptions\s*\{', g):
        sys.exit('no compileOptions block found in ' + name)
    g = re.sub(r'(compileOptions\s*\{)', r'\1\n        ' + flag, g, count=1)
    if re.search(r'^dependencies\s*\{', g, re.M):
        g = re.sub(r'^(dependencies\s*\{)', r'\1\n    ' + dep, g, count=1, flags=re.M)
    else:
        g += '\ndependencies {\n    ' + dep + '\n}\n'
    f.write_text(g)
    patched = True
    print('gradle patched:', name)
if not patched:
    sys.exit('no app/build.gradle(.kts) found')

# ---------- launcher icons
src = pathlib.Path('assets_android')
for d in src.glob('mipmap-*'):
    dst = root / 'app/src/main/res' / d.name
    if dst.exists():
        shutil.copy(d / 'ic_launcher.png', dst / 'ic_launcher.png')
        print('icon copied:', d.name)
print('done')
