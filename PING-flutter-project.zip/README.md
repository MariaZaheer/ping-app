# PING

Subscription and free-trial reminder app (university semester project).
Flutter app for Android. Upload a screenshot, PING reads the service, plan, price and dates on the phone,
you check the details, and PING reminds you before a trial ends or a subscription renews.

Build: see `START_HERE.txt`. The APK is built in the cloud by GitHub Actions (`build-apk.yml`).
