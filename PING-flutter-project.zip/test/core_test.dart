import 'package:flutter_test/flutter_test.dart';
import 'package:ping/core.dart';

void main() {
  final today = DateTime(2026, 11, 19);

  test('Canva trial text', () {
    final r = parseScreenshotText(
        'Canva Pro\nYour 7-day free trial ends on 26 November 2026.\nAfter that you will be charged PKR 1,500 per month.\nNext billing date: 27 November 2026',
        today);
    expect(r.service, 'Canva');
    expect(r.plan, 'Pro');
    expect(r.price, 'PKR 1,500/month');
    expect(r.type, 'trial');
    expect(r.trialEnd, '2026-11-26');
    expect(r.renewalDate, '2026-11-27');
    expect(r.flags['trialEnd'], 'ok');
    expect(r.readable, true);
  });

  test('Netflix numeric date is day-first and flagged', () {
    final r = parseScreenshotText('NETFLIX\nStandard plan\nRs. 1,100 / month\nNext billing date: 05/12/2026', today);
    expect(r.service, 'Netflix');
    expect(r.type, 'subscription');
    expect(r.renewalDate, '2026-12-05');
    expect(r.flags['renewalDate'], 'check');
    expect(r.plan, 'Standard Plan');
    expect(r.price, 'Rs 1,100/month');
  });

  test('Spotify US style date and dollar price', () {
    final r = parseScreenshotText('Spotify Premium Individual\nFree trial ends Dec 3, 2026\nThen \$4.99/month', today);
    expect(r.service, 'Spotify');
    expect(r.trialEnd, '2026-12-03');
    expect(r.price, '\$4.99/month');
    expect(r.plan, 'Premium Individual');
  });

  test('Date without a year is assumed and flagged', () {
    final r = parseScreenshotText('Your trial ends on 25 Nov', today);
    expect(r.trialEnd, '2026-11-25');
    expect(r.flags['trialEnd'], 'check');
  });

  test('Past year-less date rolls to next year', () {
    expect(parseScreenshotText('Renews on 3 Jan', today).renewalDate, '2027-01-03');
  });

  test('Past dates are ignored', () {
    expect(parseScreenshotText('Started 1 Oct 2026. Renews 15 Dec 2026', today).renewalDate, '2026-12-15');
  });

  test('Two dates are told apart by the closest keyword', () {
    final r = parseScreenshotText('Free trial ends on 17 Dec 2026. You will be charged on 18 Dec 2026.', today);
    expect(r.trialEnd, '2026-12-17');
    expect(r.renewalDate, '2026-12-18');
  });

  test('Free amounts are skipped', () {
    expect(findPrice('\$0.00 today then \$9.99 per month'), '\$9.99/month');
  });

  test('N-day trial with no date is estimated and flagged', () {
    final r = parseScreenshotText('Start your 14-day free trial of Notion Plus', today);
    expect(r.type, 'trial');
    expect(r.trialEnd, '2026-12-03');
    expect(r.flags['trialEnd'], 'check');
    expect(r.service, 'Notion');
  });

  test('Unreadable text', () {
    final r = parseScreenshotText('hello world', today);
    expect(r.readable, false);
    expect(parseScreenshotText('', today).readable, false);
    expect(parseScreenshotText(null, today).readable, false);
  });

  test('Invalid dates are rejected', () {
    expect(findDates('31 Feb 2026', today).length, 0);
    expect(parseIso('2026-02-30'), null);
  });

  test('Status values and filters', () {
    Sub mk(String renew, {bool cancelled = false}) =>
        Sub(id: 'x', nid: 1, service: 'X', renewalDate: renew, cancelled: cancelled);
    expect(statusOf(mk('2026-11-25'), today), 'upcoming');
    expect(statusOf(mk('2027-03-01'), today), 'active');
    expect(statusOf(mk('2026-11-01'), today), 'expired');
    expect(statusOf(mk('2026-11-25', cancelled: true), today), 'cancelled');
    expect(matchesFilter(mk('2026-11-25'), 'active', today), true);
    expect(matchesFilter(mk('2026-11-25', cancelled: true), 'active', today), false);
  });

  test('Key date and kind', () {
    final s = Sub(id: 'x', nid: 1, service: 'X', trialEnd: '2026-11-22', renewalDate: '2026-11-23');
    expect(toIso(keyDate(s, today)!), '2026-11-22');
    expect(kindOf(s, today), 'trial');
  });

  test('Reminder scheduled vs due', () {
    final s = Sub(id: 'x', nid: 1, service: 'X', trialEnd: '2026-11-22');
    final early = reminderFor(s, 3, DateTime(2026, 11, 19, 0, 30));
    expect(early.status, 'scheduled');
    expect(early.at!.hour, 9);
    expect(early.at!.day, 19);
    expect(reminderFor(s, 3, DateTime(2026, 11, 19, 10, 0)).status, 'due');
    expect(reminderFor(s, 1, DateTime(2026, 11, 19, 10, 0)).status, 'scheduled');
    s.cancelled = true;
    expect(reminderFor(s, 3, DateTime(2026, 11, 19)).status, 'none');
  });

  test('Validation', () {
    expect(validateDraft(Draft(service: 'X', type: 'subscription', renewalDate: '2026-12-01')).isEmpty, true);
    expect(validateDraft(Draft(service: '', renewalDate: '2026-12-01')).containsKey('service'), true);
    expect(validateDraft(Draft(service: 'X')).containsKey('trialEnd'), true);
    expect(validateDraft(Draft(service: 'X', type: 'trial', renewalDate: '2026-12-01')).containsKey('trialEnd'), true);
  });

  test('Password hash is stable', () {
    expect(hashPassword('s', 'p'), hashPassword('s', 'p'));
    expect(hashPassword('s', 'p') == hashPassword('s', 'q'), false);
  });
}
