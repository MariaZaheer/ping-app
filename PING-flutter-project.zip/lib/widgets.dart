// Shared colours and small widgets.
import 'package:flutter/material.dart';
import 'core.dart';

const Color kPrimary = Color(0xFF0B6E5B);
const Color kPrimaryDark = Color(0xFF085748);
const Color kPrimaryLight = Color(0xFFE3F1EE);
const Color kBg = Color(0xFFF4F6F3);
const Color kInk = Color(0xFF12211C);
const Color kMuted = Color(0xFF5B6B65);
const Color kLine = Color(0xFFDDE3DF);
const Color kWarn = Color(0xFF9A4A00);
const Color kWarnBg = Color(0xFFFFF1DD);
const Color kBad = Color(0xFFB3261E);
const Color kBadBg = Color(0xFFFDE8E6);

// Which bottom tab is open: 0 Home, 1 Add, 2 All, 3 Reminders, 4 Settings
final ValueNotifier<int> tabIndex = ValueNotifier<int>(0);

class Panel extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color borderColor;
  final Color fill;
  const Panel({super.key, required this.child, this.onTap, this.borderColor = kLine, this.fill = Colors.white});

  @override
  Widget build(BuildContext context) {
    final inner = Padding(padding: const EdgeInsets.all(16), child: child);
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: fill,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor),
      ),
      child: onTap == null
          ? inner
          : Material(
              color: Colors.transparent,
              child: InkWell(borderRadius: BorderRadius.circular(14), onTap: onTap, child: inner),
            ),
    );
  }
}

class NoteBox extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  const NoteBox(this.text, {super.key, this.bg = kWarnBg, this.fg = kWarn});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
      child: Text(text, style: TextStyle(color: fg, fontSize: 14)),
    );
  }
}

class StatusBadge extends StatelessWidget {
  final String status;
  const StatusBadge({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    String label;
    Color bg;
    Color fg;
    switch (status) {
      case 'upcoming':
        label = 'Upcoming';
        bg = kWarnBg;
        fg = kWarn;
        break;
      case 'expired':
        label = 'Expired';
        bg = const Color(0xFFECEFED);
        fg = kMuted;
        break;
      case 'cancelled':
        label = 'Cancelled';
        bg = const Color(0xFFECEFED);
        fg = kMuted;
        break;
      default:
        label = 'Active';
        bg = kPrimaryLight;
        fg = kPrimaryDark;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(label, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

class SubCard extends StatelessWidget {
  final Sub sub;
  final VoidCallback onTap;
  const SubCard({super.key, required this.sub, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final today = startOfDay(DateTime.now());
    final k = keyDate(sub, today);
    final kind = kindOf(sub, today);
    final status = statusOf(sub, today);
    var line = 'No date';
    if (k != null) {
      final n = daysBetween(today, k);
      line = '${kind == 'trial' ? 'Trial ends' : 'Renews'} ${fmtDate(k)} (${relDays(n)})';
    }
    return Panel(
      onTap: onTap,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(sub.service, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
                const SizedBox(height: 2),
                Text(line, style: const TextStyle(color: kMuted, fontSize: 14)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              StatusBadge(status: status),
              if (sub.price.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(sub.price, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class LogoPainter extends CustomPainter {
  final Color color;
  LogoPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final fill = Paint()..color = color;
    final ring1 = Paint()
      ..color = color.withAlpha(180)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    final ring2 = Paint()
      ..color = color.withAlpha(100)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawCircle(c, size.width * 0.11, fill);
    canvas.drawCircle(c, size.width * 0.27, ring1);
    canvas.drawCircle(c, size.width * 0.45, ring2);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class PingLogo extends StatelessWidget {
  final double size;
  final Color color;
  const PingLogo({super.key, this.size = 88, this.color = Colors.white});

  @override
  Widget build(BuildContext context) {
    return SizedBox(width: size, height: size, child: CustomPaint(painter: LogoPainter(color)));
  }
}

void showMsg(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
}

Future<bool> confirmDialog(BuildContext context,
    {required String title, required String text, required String ok, bool danger = false}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(text),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: Text(ok, style: TextStyle(color: danger ? kBad : kPrimary, fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );
  return r ?? false;
}

Widget bigButton(String label, VoidCallback? onPressed, {bool outlined = false, bool danger = false}) {
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(12));
  if (outlined) {
    final c = danger ? kBad : kPrimary;
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        foregroundColor: c,
        side: BorderSide(color: c),
        shape: shape,
        textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
      ),
      child: Text(label),
    );
  }
  return FilledButton(
    onPressed: onPressed,
    style: FilledButton.styleFrom(
      minimumSize: const Size.fromHeight(52),
      backgroundColor: kPrimary,
      foregroundColor: Colors.white,
      shape: shape,
      textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
    ),
    child: Text(label),
  );
}

Widget sectionTitle(String t) =>
    Padding(padding: const EdgeInsets.only(top: 4), child: Text(t, style: const TextStyle(fontSize: 15, color: kMuted)));
