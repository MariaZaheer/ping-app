// Phone notifications (local, no internet needed).
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'core.dart';
import 'store.dart';

class Notifier {
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  static const String _channelId = 'ping_reminders';
  static const int _testId = 1;

  NotificationDetails get _details => const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          'PING reminders',
          channelDescription: 'Reminders before free trials end and subscriptions renew',
          importance: Importance.high,
          priority: Priority.high,
        ),
      );

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      const settings = InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher'));
      await _plugin.initialize(settings);
      await _android?.createNotificationChannel(const AndroidNotificationChannel(
        _channelId,
        'PING reminders',
        description: 'Reminders before free trials end and subscriptions renew',
        importance: Importance.high,
      ));
      _ready = true;
    } catch (e) {
      debugPrint('Notifier init failed: $e');
    }
  }

  Future<bool> permissionGranted() async {
    if (!_ready) return false;
    try {
      return (await _android?.areNotificationsEnabled()) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> requestPermission() async {
    if (!_ready) return false;
    try {
      final ok = await _android?.requestNotificationsPermission();
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> cancelAll() async {
    if (!_ready) return;
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }

  Future<void> _schedule(int id, String title, String body, DateTime when) async {
    final at = tz.TZDateTime.from(when, tz.UTC);
    try {
      await _plugin.zonedSchedule(id, title, body, at, _details,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    } on PlatformException {
      // exact alarms not allowed on this phone: use a slightly less precise alarm
      await _plugin.zonedSchedule(id, title, body, at, _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    }
  }

  String _title(Sub s, int daysLeft) {
    final when = relDays(daysLeft);
    return kindOf(s, DateTime.now()) == 'trial' ? '${s.service}: free trial ends $when' : '${s.service} renews $when';
  }

  String _body(Sub s) {
    final k = keyDate(s, DateTime.now());
    final parts = <String>[];
    if (k != null) parts.add(fmtDate(k));
    if (s.price.isNotEmpty) parts.add(s.price);
    parts.add('Open PING to review or cancel.');
    return parts.join(' - ');
  }

  // Rebuilds all reminders from the saved subscriptions.
  Future<void> sync() async {
    if (!_ready || !appState.loggedIn) return;
    try {
      await _plugin.cancelAll();
      final d = appState.data;
      if (!d.notifications) return;
      if (!await permissionGranted()) return;
      final now = DateTime.now();
      var changed = false;
      for (final s in d.subs) {
        final r = reminderFor(s, d.reminderDays, now);
        if (r.status == 'scheduled' && r.at != null) {
          await _schedule(s.nid, _title(s, d.reminderDays), _body(s), r.at!);
        } else if (r.status == 'due' && !s.notifiedNow && r.daysLeft != null) {
          // reminder time already passed but the date is still ahead: alert once, right now
          await _plugin.show(s.nid, _title(s, r.daysLeft!), _body(s), _details);
          s.notifiedNow = true;
          changed = true;
        }
      }
      if (changed) await appState.save();
    } catch (e) {
      debugPrint('Reminder sync failed: $e');
    }
  }

  // Demo helper: a test notification in 10 seconds.
  Future<bool> sendTest() async {
    if (!_ready) return false;
    try {
      if (!await permissionGranted()) {
        if (!await requestPermission()) return false;
      }
      await _schedule(_testId, 'PING test reminder', 'This is how a PING reminder looks.',
          DateTime.now().add(const Duration(seconds: 10)));
      return true;
    } catch (e) {
      debugPrint('Test notification failed: $e');
      return false;
    }
  }
}

final Notifier notifier = Notifier();
