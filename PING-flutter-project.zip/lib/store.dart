// Local storage: accounts and subscriptions live only on this phone.
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core.dart';

class UserData {
  List<Sub> subs = <Sub>[];
  int reminderDays = 3;
  bool notifications = true;
  int nextNid = 1000;
}

class AppState extends ChangeNotifier {
  SharedPreferences? _p;
  String? email;
  UserData data = UserData();
  bool seenOnboarding = false;

  SharedPreferences get _prefs => _p!;

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    seenOnboarding = _prefs.getBool('ping.seen') ?? false;
    final s = _prefs.getString('ping.session');
    if (s != null && _users().containsKey(s)) {
      email = s;
      _load();
    }
  }

  bool get loggedIn => email != null;

  Map<String, dynamic> _users() {
    final raw = _prefs.getString('ping.users');
    if (raw == null) return <String, dynamic>{};
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  void _load() {
    final raw = _prefs.getString('ping.data.$email');
    data = UserData();
    if (raw == null) return;
    try {
      final j = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      final list = (j['subs'] ?? <dynamic>[]) as List;
      data.subs = list.map((e) => Sub.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      final days = ((j['reminderDays'] ?? 3) as num).toInt();
      data.reminderDays = reminderChoices.contains(days) ? days : 3;
      data.notifications = (j['notifications'] ?? true) as bool;
      data.nextNid = ((j['nextNid'] ?? 1000) as num).toInt();
    } catch (_) {
      data = UserData();
    }
  }

  Future<void> save() async {
    if (email != null) {
      final j = {
        'subs': data.subs.map((s) => s.toJson()).toList(),
        'reminderDays': data.reminderDays,
        'notifications': data.notifications,
        'nextNid': data.nextNid,
      };
      await _prefs.setString('ping.data.$email', jsonEncode(j));
    }
    notifyListeners();
  }

  Future<void> markOnboardingSeen() async {
    seenOnboarding = true;
    await _prefs.setBool('ping.seen', true);
  }

  String _salt() {
    final r = math.Random.secure();
    final bytes = List<int>.generate(16, (_) => r.nextInt(256));
    return base64UrlEncode(bytes);
  }

  static bool validEmail(String e) => RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(e);

  // Returns an error message, or null when it worked.
  Future<String?> signUp(String emailIn, String password) async {
    final e = emailIn.trim().toLowerCase();
    if (!validEmail(e)) return 'Enter a valid email address.';
    if (password.length < 8) return 'Password must be at least 8 characters.';
    final users = _users();
    if (users.containsKey(e)) return 'An account with this email already exists on this phone. Log in instead.';
    final salt = _salt();
    users[e] = {'salt': salt, 'hash': hashPassword(salt, password)};
    await _prefs.setString('ping.users', jsonEncode(users));
    await _prefs.setString('ping.session', e);
    email = e;
    _load();
    await save();
    return null;
  }

  Future<String?> logIn(String emailIn, String password) async {
    final e = emailIn.trim().toLowerCase();
    if (!validEmail(e)) return 'Enter a valid email address.';
    final users = _users();
    final u = users[e];
    if (u == null) return 'No account found with this email on this phone.';
    final m = Map<String, dynamic>.from(u as Map);
    if (hashPassword(m['salt'] as String, password) != m['hash']) return 'Wrong email or password.';
    await _prefs.setString('ping.session', e);
    email = e;
    _load();
    notifyListeners();
    return null;
  }

  Future<void> logOut() async {
    await _prefs.remove('ping.session');
    email = null;
    data = UserData();
    notifyListeners();
  }

  Future<void> deleteAccount() async {
    final e = email;
    if (e == null) return;
    final users = _users();
    users.remove(e);
    await _prefs.setString('ping.users', jsonEncode(users));
    await _prefs.remove('ping.data.$e');
    await logOut();
  }

  Future<void> deleteAllSubs() async {
    data.subs = <Sub>[];
    await save();
  }

  Sub? byId(String id) {
    for (final s in data.subs) {
      if (s.id == id) return s;
    }
    return null;
  }

  Future<Sub> upsert(Draft d) async {
    final Sub target = (d.id == null ? null : byId(d.id!)) ?? _createSub(d);
    target.service = d.service.trim();
    target.plan = d.plan.trim();
    target.price = d.price.trim();
    target.type = d.type;
    target.trialEnd = d.trialEnd;
    target.renewalDate = d.renewalDate;
    target.source = d.source;
    target.cancelled = d.cancelled;
    target.notifiedNow = false;
    await save();
    return target;
  }

  Sub _createSub(Draft d) {
    final s = Sub(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      nid: data.nextNid++,
      service: d.service.trim(),
    );
    data.subs.add(s);
    return s;
  }

  Future<void> deleteSub(String id) async {
    data.subs.removeWhere((s) => s.id == id);
    await save();
  }
}

final AppState appState = AppState();
