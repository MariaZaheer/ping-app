// Main tabs: Home, Add, All subscriptions, Reminders, Settings.
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'core.dart';
import 'notifier.dart';
import 'screens_auth.dart';
import 'screens_flow.dart';
import 'store.dart';
import 'widgets.dart';

class Shell extends StatelessWidget {
  const Shell({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([tabIndex, appState]),
      builder: (context, _) {
        final i = tabIndex.value;
        final List<Widget> pages = [
          HomeScreen(),
          AddScreen(),
          AllScreen(),
          RemindersScreen(),
          SettingsScreen(),
        ];
        return Scaffold(
          body: SafeArea(child: pages[i]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: i,
            backgroundColor: Colors.white,
            indicatorColor: kPrimaryLight,
            onDestinationSelected: (v) => tabIndex.value = v,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Add'),
              NavigationDestination(icon: Icon(Icons.list_alt_outlined), selectedIcon: Icon(Icons.list_alt), label: 'All'),
              NavigationDestination(
                  icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Reminders'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
            ],
          ),
        );
      },
    );
  }
}

// ------------------------------------------------------------------ Home
class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  Widget _stat(String value, String label) {
    return Expanded(
      child: Column(
        children: [
          Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: kPrimary)),
          Text(label, style: const TextStyle(fontSize: 13, color: kMuted)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = startOfDay(DateTime.now());
    final subs = appState.data.subs;
    final active = subs.where((s) => matchesFilter(s, 'active', today)).toList();
    final upcoming = subs.where((s) => statusOf(s, today) == 'upcoming').length;
    final next = sortByKeyDate(active, today).take(3).toList();
    final name = (appState.email ?? '').split('@').first;
    final initial = name.isEmpty ? '?' : name[0].toUpperCase();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Ping', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
                Text('Hi, $name', style: const TextStyle(color: kMuted)),
              ],
            ),
            CircleAvatar(backgroundColor: kPrimary, child: Text(initial, style: const TextStyle(color: Colors.white))),
          ],
        ),
        const SizedBox(height: 16),
        Panel(child: Row(children: [_stat('${active.length}', 'Active'), _stat('$upcoming', 'Upcoming (30 days)')])),
        const SizedBox(height: 12),
        sectionTitle('Next up'),
        const SizedBox(height: 8),
        if (next.isEmpty)
          const Panel(
            child: Text('No subscriptions yet. Add your first one from a screenshot.',
                textAlign: TextAlign.center, style: TextStyle(color: kMuted)),
          )
        else
          ...next.map((s) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: SubCard(sub: s, onTap: () => openDetail(context, s.id)),
              )),
        const SizedBox(height: 10),
        bigButton('Add subscription', () => tabIndex.value = 1),
        const SizedBox(height: 10),
        bigButton('All subscriptions', () => tabIndex.value = 2, outlined: true),
      ],
    );
  }
}

// ------------------------------------------------------------------ Add
class AddScreen extends StatefulWidget {
  AddScreen({super.key});

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  Future<void> _pick(ImageSource src) async {
    try {
      final XFile? f = await ImagePicker().pickImage(source: src, maxWidth: 2000);
      if (f == null || !mounted) return;
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProcessingScreen(path: f.path)));
    } on PlatformException {
      if (mounted) showMsg(context, 'Could not open it. You can enter the details manually instead.');
    } catch (_) {
      if (mounted) showMsg(context, 'Something went wrong. You can enter the details manually instead.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Add subscription', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Upload a screenshot of the trial, receipt or subscription page. Ping reads the details for you.',
            style: TextStyle(color: kMuted, fontSize: 15)),
        const SizedBox(height: 16),
        Container(
          height: 150,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kPrimary, width: 2),
          ),
          child: const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.image_outlined, size: 40, color: kPrimary),
                SizedBox(height: 8),
                Text('PNG or JPG, clear and uncropped', style: TextStyle(color: kMuted, fontSize: 14)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        bigButton('Choose from gallery', () => _pick(ImageSource.gallery)),
        const SizedBox(height: 10),
        bigButton('Take a photo', () => _pick(ImageSource.camera), outlined: true),
        const SizedBox(height: 6),
        TextButton(
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => ReviewScreen(draft: Draft(source: 'manual')))),
          child: const Text('Enter details manually', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
        ),
        const SizedBox(height: 10),
        const Text('Screenshots are read on this phone. They are not uploaded or saved.',
            style: TextStyle(color: kMuted, fontSize: 13)),
      ],
    );
  }
}

// ------------------------------------------------------------------ All subscriptions
class AllScreen extends StatefulWidget {
  AllScreen({super.key});

  @override
  State<AllScreen> createState() => _AllScreenState();
}

class _AllScreenState extends State<AllScreen> {
  String _filter = 'active';

  static const Map<String, String> _labels = {
    'active': 'Active',
    'upcoming': 'Upcoming',
    'expired': 'Expired',
    'cancelled': 'Cancelled',
  };

  @override
  Widget build(BuildContext context) {
    final today = startOfDay(DateTime.now());
    final subs = appState.data.subs;
    final shown = sortByKeyDate(subs.where((s) => matchesFilter(s, _filter, today)).toList(), today);
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('All subscriptions', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _labels.entries.map((e) {
            final n = subs.where((s) => matchesFilter(s, e.key, today)).length;
            final on = _filter == e.key;
            return ChoiceChip(
              label: Text('${e.value} ($n)'),
              selected: on,
              selectedColor: kPrimary,
              backgroundColor: Colors.white,
              showCheckmark: false,
              labelStyle: TextStyle(color: on ? Colors.white : kInk),
              onSelected: (_) => setState(() => _filter = e.key),
            );
          }).toList(),
        ),
        const SizedBox(height: 14),
        if (shown.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 30),
            child: Text(
              subs.isEmpty
                  ? 'No subscriptions yet. Tap Add to create one.'
                  : 'Nothing here. No ${_labels[_filter]!.toLowerCase()} subscriptions.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: kMuted),
            ),
          )
        else
          ...shown.map((s) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: SubCard(sub: s, onTap: () => openDetail(context, s.id)),
              )),
      ],
    );
  }
}

// ------------------------------------------------------------------ Reminders
class RemindersScreen extends StatelessWidget {
  RemindersScreen({super.key});

  Widget _alertRow(Sub s, Reminder r, bool past) {
    final kindText = kindOf(s, DateTime.now()) == 'trial' ? 'trial ends' : 'renews';
    final key = r.key;
    final title = key == null ? s.service : '${s.service} $kindText ${fmtDate(key)}';
    final when = past
        ? 'Reminder time passed (${fmtDate(r.at!)})'
        : 'Reminder on ${fmtDate(r.at!)}, 9:00 AM';
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(when, style: const TextStyle(color: kMuted, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = appState.data;
    final now = DateTime.now();
    final upcoming = <MapEntry<Sub, Reminder>>[];
    final past = <MapEntry<Sub, Reminder>>[];
    for (final s in d.subs) {
      final r = reminderFor(s, d.reminderDays, now);
      if (r.status == 'scheduled' && r.at != null) upcoming.add(MapEntry(s, r));
      if (r.status == 'due' && r.at != null) past.add(MapEntry(s, r));
    }
    upcoming.sort((a, b) => a.value.at!.compareTo(b.value.at!));
    past.sort((a, b) => b.value.at!.compareTo(a.value.at!));

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Reminders', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Remind me before', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                children: reminderChoices.map((n) {
                  final on = d.reminderDays == n;
                  return ChoiceChip(
                    label: Text(n == 1 ? '1 day' : '$n days'),
                    selected: on,
                    selectedColor: kPrimary,
                    backgroundColor: Colors.white,
                    showCheckmark: false,
                    labelStyle: TextStyle(color: on ? Colors.white : kInk),
                    onSelected: (_) async {
                      d.reminderDays = n;
                      await appState.save();
                      await notifier.sync();
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Push notifications', style: TextStyle(fontSize: 15)),
                  Switch(
                    value: d.notifications,
                    activeColor: Colors.white,
                    activeTrackColor: kPrimary,
                    onChanged: (v) async {
                      d.notifications = v;
                      if (v) await notifier.requestPermission();
                      await appState.save();
                      await notifier.sync();
                    },
                  ),
                ],
              ),
              FutureBuilder<bool>(
                future: notifier.permissionGranted(),
                builder: (context, snap) {
                  if (snap.data == false && d.notifications) {
                    return const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Text(
                          'Notifications are blocked for PING. Turn them on in your phone: Settings > Apps > PING > Notifications.',
                          style: TextStyle(color: kWarn, fontSize: 13)),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        sectionTitle('Upcoming reminders'),
        const SizedBox(height: 8),
        if (upcoming.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Text('No upcoming reminders.', style: TextStyle(color: kMuted)),
          )
        else
          ...upcoming.map((e) => _alertRow(e.key, e.value, false)),
        const SizedBox(height: 6),
        sectionTitle('Past alerts'),
        const SizedBox(height: 8),
        if (past.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Text('No past alerts.', style: TextStyle(color: kMuted)),
          )
        else
          ...past.map((e) => _alertRow(e.key, e.value, true)),
      ],
    );
  }
}

// ------------------------------------------------------------------ Settings
class SettingsScreen extends StatelessWidget {
  SettingsScreen({super.key});

  Widget _row(String label, VoidCallback onTap, {Color color = kInk}) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: TextStyle(fontSize: 15, color: color)),
            const Icon(Icons.chevron_right, color: kMuted),
          ],
        ),
      ),
    );
  }

  Future<void> _logout(BuildContext context) async {
    final nav = Navigator.of(context);
    final ok = await confirmDialog(context, title: 'Sign out?', text: 'You can log in again with your email and password.', ok: 'Sign out');
    if (!ok) return;
    await notifier.cancelAll();
    await appState.logOut();
    tabIndex.value = 0;
    nav.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AuthScreen(startSignUp: false)), (r) => false);
  }

  Future<void> _deleteAccount(BuildContext context) async {
    final nav = Navigator.of(context);
    final ok = await confirmDialog(context,
        title: 'Delete account?',
        text: 'This deletes your account and all your subscriptions from this phone. It cannot be undone.',
        ok: 'Delete',
        danger: true);
    if (!ok) return;
    await notifier.cancelAll();
    await appState.deleteAccount();
    tabIndex.value = 0;
    nav.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AuthScreen(startSignUp: true)), (r) => false);
  }

  Future<void> _privacy(BuildContext context) async {
    final wipe = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Privacy and data'),
        content: const Text(
            'Your account and subscriptions are stored only on this phone.\n\nScreenshots are read on the phone and are not uploaded or saved. PING never connects to your bank or payment accounts.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Delete all my subscriptions', style: TextStyle(color: kBad)),
          ),
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Close')),
        ],
      ),
    );
    if (wipe != true || !context.mounted) return;
    final ok = await confirmDialog(context,
        title: 'Delete all subscriptions?', text: 'This removes every subscription you added. It cannot be undone.', ok: 'Delete', danger: true);
    if (!ok) return;
    await appState.deleteAllSubs();
    await notifier.sync();
    if (context.mounted) showMsg(context, 'All subscriptions deleted.');
  }

  Future<void> _test(BuildContext context) async {
    final ok = await notifier.sendTest();
    if (!context.mounted) return;
    showMsg(
        context,
        ok
            ? 'Test reminder set. Press the home button and wait about 10 seconds.'
            : 'Could not set it. Allow notifications for PING in your phone settings.');
  }

  @override
  Widget build(BuildContext context) {
    final email = appState.email ?? '';
    final initial = email.isEmpty ? '?' : email[0].toUpperCase();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Settings', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        const SizedBox(height: 14),
        Panel(
          child: Row(
            children: [
              CircleAvatar(radius: 24, backgroundColor: kPrimary, child: Text(initial, style: const TextStyle(color: Colors.white))),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Account', style: TextStyle(fontWeight: FontWeight.w700)),
                    Text(email, style: const TextStyle(color: kMuted, fontSize: 14)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            children: [
              _row('Reminders and notifications', () => tabIndex.value = 3),
              const Divider(height: 1, color: kLine),
              _row('Privacy and data', () => _privacy(context)),
              const Divider(height: 1, color: kLine),
              _row('Send a test reminder (10 seconds)', () => _test(context)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        bigButton('Sign out', () => _logout(context), outlined: true),
        const SizedBox(height: 10),
        TextButton(
          onPressed: () => _deleteAccount(context),
          child: const Text('Delete account', style: TextStyle(color: kBad, fontWeight: FontWeight.w600, fontSize: 15)),
        ),
        const SizedBox(height: 10),
        const Center(child: Text('PING 1.0 (semester project demo build)', style: TextStyle(color: kMuted, fontSize: 12))),
      ],
    );
  }
}
