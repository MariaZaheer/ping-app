// Splash, onboarding and sign up / log in.
import 'package:flutter/material.dart';
import 'notifier.dart';
import 'screens_main.dart';
import 'store.dart';
import 'widgets.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1500), _next);
  }

  void _next() {
    if (!mounted) return;
    Widget target;
    if (appState.loggedIn) {
      target = const Shell();
      notifier.sync();
    } else if (appState.seenOnboarding) {
      target = const AuthScreen(startSignUp: false);
    } else {
      target = const OnboardingScreen();
    }
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => target));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimary,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            PingLogo(size: 96),
            SizedBox(height: 14),
            Text('Ping', style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.w800)),
            SizedBox(height: 8),
            Text('Never miss a renewal', style: TextStyle(color: Colors.white, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  Widget _step(String title, String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 2),
            Text(text, style: const TextStyle(color: kMuted, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Future<void> _go(BuildContext context, bool signUp) async {
    await appState.markOnboardingSeen();
    if (!context.mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => AuthScreen(startSignUp: signUp)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ListView(
                  children: [
                    const SizedBox(height: 16),
                    const Text('Never pay for a forgotten trial',
                        style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, height: 1.15)),
                    const SizedBox(height: 8),
                    const Text('Ping reminds you before a free trial ends or a subscription renews.',
                        style: TextStyle(color: kMuted, fontSize: 15)),
                    const SizedBox(height: 8),
                    _step('1. Upload a screenshot', 'From your gallery or camera.'),
                    _step('2. Ping reads the dates', 'You check and fix anything it got wrong.'),
                    _step('3. Get a reminder', 'A notification before you are charged.'),
                  ],
                ),
              ),
              bigButton('Get started', () => _go(context, true)),
              const SizedBox(height: 10),
              bigButton('I already have an account', () => _go(context, false), outlined: true),
            ],
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends StatefulWidget {
  final bool startSignUp;
  const AuthScreen({super.key, required this.startSignUp});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late bool _signUp;
  final TextEditingController _email = TextEditingController();
  final TextEditingController _pass = TextEditingController();
  String? _error;
  bool _busy = false;
  bool _hide = true;

  @override
  void initState() {
    super.initState();
    _signUp = widget.startSignUp;
  }

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final String? err =
        _signUp ? await appState.signUp(_email.text, _pass.text) : await appState.logIn(_email.text, _pass.text);
    if (!mounted) return;
    if (err != null) {
      setState(() {
        _busy = false;
        _error = err;
      });
      return;
    }
    await notifier.requestPermission();
    await notifier.sync();
    if (!mounted) return;
    tabIndex.value = 0;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const Shell()), (r) => false);
  }

  InputDecoration _dec(String label, {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: Colors.white,
      suffixIcon: suffix,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kLine)),
      focusedBorder:
          OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kPrimary, width: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 16),
            const Text('Welcome to Ping', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            Row(
              children: [
                ChoiceChip(
                  label: const Text('Sign up'),
                  selected: _signUp,
                  selectedColor: kPrimary,
                  backgroundColor: Colors.white,
                  labelStyle: TextStyle(color: _signUp ? Colors.white : kInk),
                  showCheckmark: false,
                  onSelected: (_) => setState(() {
                    _signUp = true;
                    _error = null;
                  }),
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('Log in'),
                  selected: !_signUp,
                  selectedColor: kPrimary,
                  backgroundColor: Colors.white,
                  labelStyle: TextStyle(color: !_signUp ? Colors.white : kInk),
                  showCheckmark: false,
                  onSelected: (_) => setState(() {
                    _signUp = false;
                    _error = null;
                  }),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              autocorrect: false,
              decoration: _dec('Email'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _pass,
              obscureText: _hide,
              autocorrect: false,
              decoration: _dec(
                _signUp ? 'Password (at least 8 characters)' : 'Password',
                suffix: IconButton(
                  icon: Icon(_hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
              onSubmitted: (_) => _submit(),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              NoteBox(_error!, bg: kBadBg, fg: kBad),
            ],
            const SizedBox(height: 16),
            bigButton(_busy ? 'Please wait...' : (_signUp ? 'Create account' : 'Log in'), _busy ? null : _submit),
            const SizedBox(height: 16),
            const Text('Your account and subscriptions stay on this phone. Screenshots are read on the phone and are not uploaded.',
                style: TextStyle(color: kMuted, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
