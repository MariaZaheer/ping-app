// PING core logic: dates, screenshot-text parsing, statuses and reminders.
// Plain Dart (no Flutter imports) so it can be unit tested.
import 'dart:convert';
import 'dart:math' as math;
import 'package:crypto/crypto.dart' as crypto;

const int upcomingDays = 30; // "Upcoming" = key date within the next 30 days
const int reminderHour = 9; // reminders fire at 09:00 local time
const List<int> reminderChoices = [1, 3, 7];
const int _inf = 1 << 30;

const List<String> monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const Map<String, int> _months = {
  'jan': 1, 'january': 1, 'feb': 2, 'february': 2, 'mar': 3, 'march': 3, 'apr': 4, 'april': 4, 'may': 5,
  'jun': 6, 'june': 6, 'jul': 7, 'july': 7, 'aug': 8, 'august': 8, 'sep': 9, 'sept': 9, 'september': 9,
  'oct': 10, 'october': 10, 'nov': 11, 'november': 11, 'dec': 12, 'december': 12,
};
const String _monthRx =
    r'(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec)';

const List<String> cancelSteps = [
  "Open the service's own app or website and sign in.",
  'Go to Account, Settings, Billing or Subscription.',
  'Choose Cancel (or turn off auto-renew) and confirm.',
  'Keep the confirmation message or email as proof.',
];

// ---------------------------------------------------------------- dates
String _pad(int n) => n < 10 ? '0$n' : '$n';

bool isValidYmd(int y, int m, int d) {
  final dt = DateTime(y, m, d);
  return dt.year == y && dt.month == m && dt.day == d;
}

DateTime? parseIso(String? s) {
  if (s == null) return null;
  final m = RegExp(r'^(\d{4})-(\d{2})-(\d{2})$').firstMatch(s);
  if (m == null) return null;
  final y = int.parse(m.group(1)!);
  final mo = int.parse(m.group(2)!);
  final d = int.parse(m.group(3)!);
  return isValidYmd(y, mo, d) ? DateTime(y, mo, d) : null;
}

String toIso(DateTime d) => '${d.year}-${_pad(d.month)}-${_pad(d.day)}';
DateTime startOfDay(DateTime d) => DateTime(d.year, d.month, d.day);
DateTime addDays(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);

int daysBetween(DateTime a, DateTime b) {
  return DateTime.utc(b.year, b.month, b.day).difference(DateTime.utc(a.year, a.month, a.day)).inDays;
}

String fmtDate(DateTime d) => '${d.day} ${monthNames[d.month - 1]} ${d.year}';

String fmtIso(String s) {
  final d = parseIso(s);
  return d == null ? '' : fmtDate(d);
}

String relDays(int n) {
  if (n == 0) return 'today';
  if (n == 1) return 'tomorrow';
  if (n == -1) return 'yesterday';
  return n > 0 ? 'in $n days' : '${-n} days ago';
}

// ---------------------------------------------------------------- models
class Sub {
  String id;
  int nid; // number used for the phone notification
  String service;
  String plan;
  String price;
  String type; // 'trial' or 'subscription'
  String trialEnd; // yyyy-mm-dd or ''
  String renewalDate; // yyyy-mm-dd or ''
  bool cancelled;
  String source; // 'screenshot' or 'manual'
  bool notifiedNow;

  Sub({
    required this.id,
    required this.nid,
    required this.service,
    this.plan = '',
    this.price = '',
    this.type = 'subscription',
    this.trialEnd = '',
    this.renewalDate = '',
    this.cancelled = false,
    this.source = 'manual',
    this.notifiedNow = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'nid': nid,
        'service': service,
        'plan': plan,
        'price': price,
        'type': type,
        'trialEnd': trialEnd,
        'renewalDate': renewalDate,
        'cancelled': cancelled,
        'source': source,
        'notifiedNow': notifiedNow,
      };

  factory Sub.fromJson(Map<String, dynamic> j) => Sub(
        id: (j['id'] ?? '') as String,
        nid: ((j['nid'] ?? 0) as num).toInt(),
        service: (j['service'] ?? '') as String,
        plan: (j['plan'] ?? '') as String,
        price: (j['price'] ?? '') as String,
        type: (j['type'] ?? 'subscription') as String,
        trialEnd: (j['trialEnd'] ?? '') as String,
        renewalDate: (j['renewalDate'] ?? '') as String,
        cancelled: (j['cancelled'] ?? false) as bool,
        source: (j['source'] ?? 'manual') as String,
        notifiedNow: (j['notifiedNow'] ?? false) as bool,
      );
}

// What the user edits on the Review screen.
class Draft {
  String? id;
  int? nid;
  bool cancelled;
  bool isEdit;
  String source;
  String service;
  String plan;
  String price;
  String type;
  String trialEnd;
  String renewalDate;
  Map<String, String> flags;

  Draft({
    this.id,
    this.nid,
    this.cancelled = false,
    this.isEdit = false,
    this.source = 'manual',
    this.service = '',
    this.plan = '',
    this.price = '',
    this.type = 'subscription',
    this.trialEnd = '',
    this.renewalDate = '',
    Map<String, String>? flags,
  }) : flags = flags ?? <String, String>{};

  factory Draft.fromParsed(ParsedSub p) => Draft(
        source: 'screenshot',
        service: p.service,
        plan: p.plan,
        price: p.price,
        type: p.type,
        trialEnd: p.trialEnd,
        renewalDate: p.renewalDate,
        flags: Map<String, String>.from(p.flags),
      );

  factory Draft.fromSub(Sub s) => Draft(
        id: s.id,
        nid: s.nid,
        cancelled: s.cancelled,
        isEdit: true,
        source: s.source,
        service: s.service,
        plan: s.plan,
        price: s.price,
        type: s.type,
        trialEnd: s.trialEnd,
        renewalDate: s.renewalDate,
      );
}

class ParsedSub {
  String service = '';
  String plan = '';
  String price = '';
  String type = 'subscription';
  String trialEnd = '';
  String renewalDate = '';
  // 'ok' = confident, 'check' = please confirm, 'missing' = not found
  Map<String, String> flags = {
    'service': 'missing',
    'plan': 'missing',
    'price': 'missing',
    'trialEnd': 'missing',
    'renewalDate': 'missing',
  };
  bool get readable => service.isNotEmpty || trialEnd.isNotEmpty || renewalDate.isNotEmpty;
}

class DateHit {
  final int idx;
  final int end;
  final DateTime date;
  final bool yearAssumed;
  final bool ambiguous;
  DateHit(this.idx, this.end, this.date, this.yearAssumed, this.ambiguous);
}

class _PriceHit {
  final int idx;
  final String cur;
  final String amt;
  final String? per;
  _PriceHit(this.idx, this.cur, this.amt, this.per);
}

// ---------------------------------------------------------------- parsing
final List<MapEntry<String, RegExp>> _services = [
  MapEntry('Netflix', RegExp(r'\bnetflix\b', caseSensitive: false)),
  MapEntry('Spotify', RegExp(r'\bspotify\b', caseSensitive: false)),
  MapEntry('Canva', RegExp(r'\bcanva\b', caseSensitive: false)),
  MapEntry('YouTube Premium', RegExp(r'\byoutube\b', caseSensitive: false)),
  MapEntry('Disney+', RegExp(r'\bdisney\s?\+|\bdisney\s?plus\b', caseSensitive: false)),
  MapEntry('Amazon Prime', RegExp(r'\bprime\s+video\b|\bamazon\s+prime\b|\bprime\b', caseSensitive: false)),
  MapEntry('ChatGPT', RegExp(r'\bchatgpt\b|\bopenai\b', caseSensitive: false)),
  MapEntry('Claude', RegExp(r'\banthropic\b|\bclaude\b', caseSensitive: false)),
  MapEntry('Adobe', RegExp(r'\badobe\b', caseSensitive: false)),
  MapEntry('Microsoft 365', RegExp(r'\bmicrosoft\s*365\b|\boffice\s*365\b', caseSensitive: false)),
  MapEntry('Apple', RegExp(r'\bicloud\b|\bapple\s+(music|tv|one|arcade)\b', caseSensitive: false)),
  MapEntry('Google One', RegExp(r'\bgoogle\s+one\b', caseSensitive: false)),
  MapEntry('Udemy', RegExp(r'\budemy\b', caseSensitive: false)),
  MapEntry('Coursera', RegExp(r'\bcoursera\b', caseSensitive: false)),
  MapEntry('Duolingo', RegExp(r'\bduolingo\b', caseSensitive: false)),
  MapEntry('Notion', RegExp(r'\bnotion\b', caseSensitive: false)),
  MapEntry('Figma', RegExp(r'\bfigma\b', caseSensitive: false)),
  MapEntry('Grammarly', RegExp(r'\bgrammarly\b', caseSensitive: false)),
  MapEntry('LinkedIn Premium', RegExp(r'\blinkedin\b', caseSensitive: false)),
  MapEntry('Dropbox', RegExp(r'\bdropbox\b', caseSensitive: false)),
  MapEntry('Zoom', RegExp(r'\bzoom\b', caseSensitive: false)),
  MapEntry('GitHub', RegExp(r'\bgithub\b', caseSensitive: false)),
  MapEntry('Midjourney', RegExp(r'\bmidjourney\b', caseSensitive: false)),
  MapEntry('Perplexity', RegExp(r'\bperplexity\b', caseSensitive: false)),
  MapEntry('Shahid', RegExp(r'\bshahid\b', caseSensitive: false)),
  MapEntry('Careem Plus', RegExp(r'\bcareem\b', caseSensitive: false)),
];

final RegExp _planRe = RegExp(
    r'\b(premium|pro|plus|standard|basic|family|individual|student|duo|mobile|team|business|personal|starter|essential|ultimate|annual|monthly)\b(?:\s+(individual|family|student|duo|plan|annual|monthly))?',
    caseSensitive: false);
final RegExp _trialRe = RegExp(r'\btrial\b|\bfree\s+(?:until|till|through|for)\b', caseSensitive: false);
final RegExp _renewRe = RegExp(
    r'\b(?:renews?|renewal|renewing|auto-?renews?|next\s+(?:billing|payment|charge|bill)|billing\s+date|billed|charged?|payment\s+date|due|subscription\s+(?:ends|expires)|valid\s+(?:until|till|through))\b',
    caseSensitive: false);

List<DateHit> findDates(String text, DateTime today) {
  final out = <DateHit>[];
  final y0 = today.year;

  void push(int idx, int len, int? y, int mo, int d, bool ambiguous) {
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return;
    var yearAssumed = false;
    int yy;
    if (y == null) {
      yy = y0;
      yearAssumed = true;
      if (isValidYmd(yy, mo, d) && daysBetween(today, DateTime(yy, mo, d)) < 0) yy = y0 + 1;
    } else {
      yy = y;
    }
    if (yy < 100) yy += 2000;
    if (!isValidYmd(yy, mo, d)) return;
    out.add(DateHit(idx, idx + len, DateTime(yy, mo, d), yearAssumed, ambiguous));
  }

  // 2026-10-17
  for (final m in RegExp(r'\b(\d{4})-(\d{1,2})-(\d{1,2})\b').allMatches(text)) {
    push(m.start, m.end - m.start, int.parse(m.group(1)!), int.parse(m.group(2)!), int.parse(m.group(3)!), false);
  }
  // 17 Oct 2026 / 17th October / 17-Oct-26
  final dayMonth = RegExp(r'\b(\d{1,2})(?:st|nd|rd|th)?[\s\-]+' + _monthRx + r'\b\.?(?:,?\s+(\d{4}))?', caseSensitive: false);
  for (final m in dayMonth.allMatches(text)) {
    final yr = m.group(3);
    push(m.start, m.end - m.start, yr == null ? null : int.parse(yr), _months[m.group(2)!.toLowerCase()]!,
        int.parse(m.group(1)!), false);
  }
  // Oct 17, 2026 / October 17
  final monthDay = RegExp(r'\b' + _monthRx + r'\b\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b(?:,?\s+(\d{4}))?', caseSensitive: false);
  for (final m in monthDay.allMatches(text)) {
    final yr = m.group(3);
    push(m.start, m.end - m.start, yr == null ? null : int.parse(yr), _months[m.group(1)!.toLowerCase()]!,
        int.parse(m.group(2)!), false);
  }
  // 17/10/2026, 10/17/2026, 17.10.26 (day first unless the second number cannot be a month)
  for (final m in RegExp(r'\b(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4}|\d{2})\b').allMatches(text)) {
    final a = int.parse(m.group(1)!);
    final b = int.parse(m.group(2)!);
    int day;
    int mon;
    var amb = false;
    if (a > 12) {
      day = a;
      mon = b;
    } else if (b > 12) {
      mon = a;
      day = b;
    } else {
      day = a;
      mon = b;
      amb = a != b;
    }
    push(m.start, m.end - m.start, int.parse(m.group(3)!), mon, day, amb);
  }

  // drop overlaps (keep the longest match at a position)
  out.sort((p, q) {
    final c = p.idx.compareTo(q.idx);
    if (c != 0) return c;
    return (q.end - q.idx).compareTo(p.end - p.idx);
  });
  final kept = <DateHit>[];
  for (final h in out) {
    if (kept.isNotEmpty && h.idx < kept.last.end) continue;
    kept.add(h);
  }
  return kept;
}

int _nearest(String text, RegExp rx, int dateStart, int dateEnd) {
  var best = _inf;
  for (final m in rx.allMatches(text)) {
    int dist;
    if (m.end <= dateStart) {
      dist = dateStart - m.end;
    } else if (m.start >= dateEnd) {
      dist = (m.start - dateEnd) + 20; // keyword after the date counts less
    } else {
      dist = 0;
    }
    if (dist < best) best = dist;
  }
  return best <= 70 ? best : _inf;
}

String findPrice(String text) {
  final re1 = RegExp(
      r'(PKR|RS\.?|USD|EUR|GBP|AED|INR|CAD|AUD|[$€£₹])\s?(\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)(?:\s?(?:/|per\s+|a\s+)\s?(month|mo|year|yr|week))?',
      caseSensitive: false);
  final re2 = RegExp(
      r'(\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)\s?(PKR|RS|USD|EUR|GBP|AED|INR)\b(?:\s?(?:/|per\s+)\s?(month|mo|year|yr|week))?',
      caseSensitive: false);
  final cands = <_PriceHit>[];
  for (final m in re1.allMatches(text)) {
    cands.add(_PriceHit(m.start, m.group(1)!, m.group(2)!, m.group(3)));
  }
  for (final m in re2.allMatches(text)) {
    cands.add(_PriceHit(m.start, m.group(2)!, m.group(1)!, m.group(3)));
  }
  cands.sort((a, b) => a.idx.compareTo(b.idx));
  for (final c in cands) {
    final val = double.tryParse(c.amt.replaceAll(',', '')) ?? 0;
    if (!(val > 0)) continue;
    var cur = c.cur.toUpperCase().replaceAll(RegExp(r'\.$'), '');
    if (cur == 'RS') cur = 'Rs';
    var per = c.per == null ? '' : c.per!.toLowerCase();
    if (per.isEmpty) {
      final around = text.substring(math.max(0, c.idx - 40), math.min(text.length, c.idx + 60));
      if (RegExp(r'per\s+month|monthly|/\s?month|a\s+month', caseSensitive: false).hasMatch(around)) {
        per = 'month';
      } else if (RegExp(r'per\s+year|yearly|annual|/\s?year|a\s+year', caseSensitive: false).hasMatch(around)) {
        per = 'year';
      }
    }
    if (per == 'mo') per = 'month';
    if (per == 'yr') per = 'year';
    final sep = RegExp(r'^[A-Za-z]').hasMatch(cur) ? ' ' : '';
    return cur + sep + c.amt + (per.isNotEmpty ? '/$per' : '');
  }
  return '';
}

ParsedSub parseScreenshotText(String? input, DateTime now) {
  final today = startOfDay(now);
  final text = (input ?? '').replaceAll(RegExp(r'[ \t]+'), ' ');
  final lower = text.toLowerCase();
  final res = ParsedSub();

  // service: the known service that appears first in the text
  var bestIdx = _inf;
  for (final e in _services) {
    final m = e.value.firstMatch(text);
    if (m != null && m.start < bestIdx) {
      bestIdx = m.start;
      res.service = e.key;
    }
  }
  if (res.service.isNotEmpty) res.flags['service'] = 'ok';

  // plan
  final pm = _planRe.firstMatch(text);
  if (pm != null) {
    final words = pm.group(0)!.trim().split(RegExp(r'\s+')).map((w) {
      return w.isEmpty ? w : w[0].toUpperCase() + w.substring(1).toLowerCase();
    }).toList();
    res.plan = words.join(' ');
    res.flags['plan'] = 'check';
  }

  // price
  res.price = findPrice(text);
  if (res.price.isNotEmpty) res.flags['price'] = 'check';

  // trial or subscription
  final hasTrial = RegExp(r'\btrial\b|\bfree\s+(?:until|till|for)\b', caseSensitive: false).hasMatch(text);
  res.type = hasTrial ? 'trial' : 'subscription';

  // dates (only today or later are useful)
  final dates = findDates(text, today).where((d) => daysBetween(today, d.date) >= 0).toList();
  final unknown = <DateHit>[];
  for (final d in dates) {
    final dt = _nearest(lower, _trialRe, d.idx, d.end);
    final dr = _nearest(lower, _renewRe, d.idx, d.end);
    final String kind = (dt == _inf && dr == _inf) ? 'unknown' : (dt <= dr ? 'trial' : 'renew');
    final sure = kind != 'unknown' && !d.yearAssumed && !d.ambiguous;
    if (kind == 'trial' && res.trialEnd.isEmpty) {
      res.trialEnd = toIso(d.date);
      res.flags['trialEnd'] = sure ? 'ok' : 'check';
    } else if (kind == 'renew' && res.renewalDate.isEmpty) {
      res.renewalDate = toIso(d.date);
      res.flags['renewalDate'] = sure ? 'ok' : 'check';
    } else if (kind == 'unknown') {
      unknown.add(d);
    }
  }
  for (final u in unknown) {
    if (res.type == 'trial' && res.trialEnd.isEmpty) {
      res.trialEnd = toIso(u.date);
      res.flags['trialEnd'] = 'check';
    } else if (res.renewalDate.isEmpty) {
      res.renewalDate = toIso(u.date);
      res.flags['renewalDate'] = 'check';
    }
  }

  // "7-day free trial" with no explicit end date: estimate from today (always flagged)
  if (hasTrial && res.trialEnd.isEmpty) {
    final t = RegExp(
            r'\b(\d{1,3})[\s\-]*(day|week)s?\s+(?:free\s+)?trial\b|\bfree\s+trial\s+(?:for|of)\s+(\d{1,3})\s*(day|week)s?\b',
            caseSensitive: false)
        .firstMatch(text);
    if (t != null) {
      final nStr = t.group(1) ?? t.group(3);
      final unit = (t.group(2) ?? t.group(4) ?? 'day').toLowerCase();
      final n = (int.tryParse(nStr ?? '') ?? 0) * (unit == 'week' ? 7 : 1);
      if (n > 0 && n <= 120) {
        res.trialEnd = toIso(addDays(today, n));
        res.flags['trialEnd'] = 'check';
      }
    }
  }
  return res;
}

// ---------------------------------------------------------------- status and reminders
DateTime? keyDate(Sub s, DateTime today) {
  final t = startOfDay(today);
  final c = <DateTime>[];
  final a = parseIso(s.trialEnd);
  final b = parseIso(s.renewalDate);
  if (a != null) c.add(a);
  if (b != null) c.add(b);
  if (c.isEmpty) return null;
  c.sort();
  for (final d in c) {
    if (daysBetween(t, d) >= 0) return d;
  }
  return c.last;
}

String statusOf(Sub s, DateTime today) {
  final t = startOfDay(today);
  if (s.cancelled) return 'cancelled';
  final k = keyDate(s, t);
  if (k == null) return 'expired';
  final n = daysBetween(t, k);
  if (n < 0) return 'expired';
  return n <= upcomingDays ? 'upcoming' : 'active';
}

bool matchesFilter(Sub s, String filter, DateTime today) {
  final st = statusOf(s, today);
  if (filter == 'active') return st == 'active' || st == 'upcoming';
  return st == filter;
}

List<Sub> sortByKeyDate(List<Sub> list, DateTime today) {
  final copy = List<Sub>.from(list);
  copy.sort((a, b) {
    final ka = keyDate(a, today);
    final kb = keyDate(b, today);
    final va = ka == null ? 1 << 62 : ka.millisecondsSinceEpoch;
    final vb = kb == null ? 1 << 62 : kb.millisecondsSinceEpoch;
    return va.compareTo(vb);
  });
  return copy;
}

String kindOf(Sub s, DateTime today) {
  final k = keyDate(s, today);
  final t = parseIso(s.trialEnd);
  if (t != null && k != null && t.year == k.year && t.month == k.month && t.day == k.day) return 'trial';
  return 'renewal';
}

class Reminder {
  final String status; // 'scheduled' (future), 'due' (time passed, date still ahead), 'none'
  final DateTime? at;
  final DateTime? key;
  final int? daysLeft;
  const Reminder(this.status, this.at, this.key, this.daysLeft);
}

Reminder reminderFor(Sub s, int days, DateTime now) {
  final today = startOfDay(now);
  if (s.cancelled) return const Reminder('none', null, null, null);
  final k = keyDate(s, today);
  if (k == null || daysBetween(today, k) < 0) return Reminder('none', null, k, null);
  final base = addDays(k, -days);
  final at = DateTime(base.year, base.month, base.day, reminderHour);
  return Reminder(at.isAfter(now) ? 'scheduled' : 'due', at, k, daysBetween(today, k));
}

Map<String, String> validateDraft(Draft d) {
  final e = <String, String>{};
  final service = d.service.trim();
  if (service.isEmpty) e['service'] = 'Enter the service name.';
  if (service.length > 60) e['service'] = 'Service name is too long.';
  if (d.plan.length > 60) e['plan'] = 'Plan is too long.';
  if (d.price.length > 30) e['price'] = 'Price is too long.';
  final hasT = d.trialEnd.isNotEmpty;
  final hasR = d.renewalDate.isNotEmpty;
  if (hasT && parseIso(d.trialEnd) == null) e['trialEnd'] = 'Enter a valid date.';
  if (hasR && parseIso(d.renewalDate) == null) e['renewalDate'] = 'Enter a valid date.';
  if (!hasT && !hasR) {
    e['trialEnd'] = 'Enter at least one date.';
    e['renewalDate'] = 'Enter at least one date.';
  }
  if (d.type == 'trial' && !hasT) e['trialEnd'] = 'Enter the trial end date.';
  return e;
}

// ---------------------------------------------------------------- passwords (demo level)
String hashPassword(String salt, String password) {
  return crypto.sha256.convert(utf8.encode('$salt:$password')).toString();
}
