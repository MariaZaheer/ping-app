// Add flow and detail: Processing -> Review -> Subscription details.
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'core.dart';
import 'notifier.dart';
import 'ocr.dart';
import 'store.dart';
import 'widgets.dart';

void openDetail(BuildContext context, String id) {
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => DetailScreen(id: id)));
}

// ------------------------------------------------------------------ Processing
class ProcessingScreen extends StatefulWidget {
  final String path;
  const ProcessingScreen({super.key, required this.path});

  @override
  State<ProcessingScreen> createState() => _ProcessingScreenState();
}

class _ProcessingScreenState extends State<ProcessingScreen> {
  int _step = 1; // 1 loaded, 2 reading text, 3 understanding, 4 finding dates and price, 5 done
  String? _error;
  bool _cancelled = false;

  @override
  void initState() {
    super.initState();
    _run();
  }

  @override
  void dispose() {
    _cancelled = true;
    super.dispose();
  }

  bool get _stop => _cancelled || !mounted;

  Future<void> _run() async {
    try {
      await Future.delayed(const Duration(milliseconds: 300));
      if (_stop) return;
      setState(() => _step = 2);
      final text = await OcrService.read(widget.path).timeout(const Duration(seconds: 60));
      if (_stop) return;
      setState(() => _step = 3);
      final parsed = parseScreenshotText(text, DateTime.now());
      await Future.delayed(const Duration(milliseconds: 350));
      if (_stop) return;
      setState(() => _step = 4);
      await Future.delayed(const Duration(milliseconds: 350));
      if (_stop) return;
      setState(() => _step = 5);
      await OcrService.deleteTemp(widget.path);
      await Future.delayed(const Duration(milliseconds: 200));
      if (_stop) return;
      if (!parsed.readable) {
        setState(() => _error = 'PING could not find a service name or a date in this screenshot.');
        return;
      }
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => ReviewScreen(draft: Draft.fromParsed(parsed))));
    } on TimeoutException {
      OcrService.deleteTemp(widget.path);
      if (_stop) return;
      setState(() => _error = 'Reading the screenshot took too long.');
    } catch (_) {
      OcrService.deleteTemp(widget.path);
      if (_stop) return;
      setState(() => _error = 'Something went wrong while reading the screenshot.');
    }
  }

  Widget _stepRow(String label, int number) {
    Widget lead;
    Color color = kInk;
    if (_step > number) {
      lead = const Icon(Icons.check_circle, color: kPrimary, size: 22);
    } else if (_step == number) {
      lead = const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: kPrimary));
    } else {
      lead = const Icon(Icons.radio_button_unchecked, color: kMuted, size: 22);
      color = kMuted;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          SizedBox(width: 26, child: Center(child: lead)),
          const SizedBox(width: 10),
          Text(label, style: TextStyle(fontSize: 15, color: color)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final failed = _error != null;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 12),
            Text(failed ? 'Could not read it' : 'Reading your screenshot',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            if (!failed) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: LinearProgressIndicator(
                  value: (_step - 1) / 4.0 + 0.05,
                  minHeight: 10,
                  backgroundColor: kLine,
                  color: kPrimary,
                ),
              ),
              const SizedBox(height: 16),
              Panel(
                child: Column(
                  children: [
                    _stepRow('Screenshot loaded', 1),
                    _stepRow('Reading text (OCR)', 2),
                    _stepRow('Understanding details (AI)', 3),
                    _stepRow('Finding dates and price', 4),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Text('This usually takes a few seconds. The screenshot stays on your phone.',
                  style: TextStyle(color: kMuted, fontSize: 14)),
              const SizedBox(height: 24),
              bigButton('Cancel', () => Navigator.of(context).pop(), outlined: true),
            ] else ...[
              NoteBox(_error!, bg: kBadBg, fg: kBad),
              const SizedBox(height: 8),
              const Text('Tips: use a sharp, uncropped screenshot that shows the service name and the date.',
                  style: TextStyle(color: kMuted, fontSize: 14)),
              const SizedBox(height: 20),
              bigButton('Try another screenshot', () => Navigator.of(context).pop()),
              const SizedBox(height: 10),
              bigButton(
                'Enter details manually',
                () => Navigator.of(context)
                    .pushReplacement(MaterialPageRoute(builder: (_) => ReviewScreen(draft: Draft(source: 'manual')))),
                outlined: true,
              ),
              const SizedBox(height: 6),
              TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
            ],
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------ Review / edit
class ReviewScreen extends StatefulWidget {
  final Draft draft;
  const ReviewScreen({super.key, required this.draft});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  late final TextEditingController _service;
  late final TextEditingController _plan;
  late final TextEditingController _price;
  late String _type;
  late String _trialEnd;
  late String _renewal;
  Map<String, String> _errors = <String, String>{};
  final Set<String> _touched = <String>{};
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final d = widget.draft;
    _service = TextEditingController(text: d.service);
    _plan = TextEditingController(text: d.plan);
    _price = TextEditingController(text: d.price);
    _type = d.type;
    _trialEnd = d.trialEnd;
    _renewal = d.renewalDate;
  }

  @override
  void dispose() {
    _service.dispose();
    _plan.dispose();
    _price.dispose();
    super.dispose();
  }

  bool get _fromScan => widget.draft.source == 'screenshot' && !widget.draft.isEdit;

  // Should this field be highlighted for the user to check?
  bool _needsCheck(String key) {
    if (!_fromScan || _touched.contains(key)) return false;
    final f = widget.draft.flags[key];
    if (f == null) return false;
    if (f == 'check') return true;
    if (f == 'missing') {
      if (key == 'service') return true;
      if (key == 'trialEnd') return _type == 'trial';
      if (key == 'renewalDate') return _type == 'subscription';
    }
    return false;
  }

  String _flagText(String key) {
    return widget.draft.flags[key] == 'missing' ? 'Not found. Please enter it.' : 'Please check this.';
  }

  OutlineInputBorder _border(Color c, double w) =>
      OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: c, width: w));

  InputDecoration _dec(String key, String label, {Widget? suffix}) {
    final flagged = _needsCheck(key);
    return InputDecoration(
      labelText: label,
      errorText: _errors[key],
      helperText: flagged ? _flagText(key) : null,
      helperStyle: const TextStyle(color: kWarn),
      filled: true,
      fillColor: Colors.white,
      suffixIcon: suffix,
      border: _border(kLine, 1),
      enabledBorder: _border(flagged ? kWarn : kLine, flagged ? 2 : 1),
      focusedBorder: _border(kPrimary, 2),
    );
  }

  Widget _textField(String key, String label, TextEditingController c, {TextInputType? type}) {
    return TextField(
      controller: c,
      keyboardType: type,
      textCapitalization: TextCapitalization.words,
      onChanged: (_) => setState(() {
        _touched.add(key);
        _errors.remove(key);
      }),
      decoration: _dec(key, label),
    );
  }

  Widget _dateField(String key, String label, String value, void Function(String) onChanged) {
    return InkWell(
      onTap: () async {
        final init = parseIso(value) ?? startOfDay(DateTime.now());
        final picked = await showDatePicker(
          context: context,
          initialDate: init,
          firstDate: DateTime(2020),
          lastDate: DateTime(2100),
        );
        if (picked != null && mounted) {
          setState(() {
            onChanged(toIso(picked));
            _touched.add(key);
            _errors.remove(key);
          });
        }
      },
      child: InputDecorator(
        decoration: _dec(
          key,
          label,
          suffix: value.isEmpty
              ? const Icon(Icons.calendar_today_outlined)
              : IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () => setState(() {
                    onChanged('');
                    _touched.add(key);
                  }),
                ),
        ),
        child: Text(
          value.isEmpty ? 'Select date' : fmtIso(value),
          style: TextStyle(fontSize: 16, color: value.isEmpty ? kMuted : kInk),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_saving) return;
    final d = widget.draft;
    final draft = Draft(
      id: d.id,
      nid: d.nid,
      cancelled: d.cancelled,
      isEdit: d.isEdit,
      source: d.source,
      service: _service.text,
      plan: _plan.text,
      price: _price.text,
      type: _type,
      trialEnd: _trialEnd,
      renewalDate: _renewal,
    );
    final errors = validateDraft(draft);
    if (errors.isNotEmpty) {
      setState(() => _errors = errors);
      return;
    }
    setState(() => _saving = true);
    final sub = await appState.upsert(draft);
    await notifier.sync();
    if (!mounted) return;
    final nav = Navigator.of(context);
    if (d.isEdit) {
      nav.pop();
    } else {
      nav.popUntil((r) => r.isFirst);
      tabIndex.value = 0;
      nav.push(MaterialPageRoute(builder: (_) => DetailScreen(id: sub.id)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.draft;
    final title = d.isEdit ? 'Edit details' : (_fromScan ? 'Check the details' : 'Add subscription');
    final anyFlag = ['service', 'plan', 'price', 'trialEnd', 'renewalDate'].any(_needsCheck);
    return Scaffold(
      appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800))),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
          children: [
            if (anyFlag) ...[
              const NoteBox('PING could not be sure about some details. Please check the highlighted fields.'),
              const SizedBox(height: 14),
            ],
            _textField('service', 'Service', _service),
            const SizedBox(height: 12),
            _textField('plan', 'Plan', _plan),
            const SizedBox(height: 12),
            _textField('price', 'Price (for example PKR 1,500/month)', _price),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment<String>(value: 'trial', label: Text('Free trial')),
                ButtonSegment<String>(value: 'subscription', label: Text('Paid subscription')),
              ],
              selected: {_type},
              showSelectedIcon: false,
              onSelectionChanged: (s) => setState(() => _type = s.first),
            ),
            const SizedBox(height: 12),
            _dateField('trialEnd', 'Trial ends', _trialEnd, (v) => _trialEnd = v),
            const SizedBox(height: 12),
            _dateField('renewalDate', 'Renews on', _renewal, (v) => _renewal = v),
            const SizedBox(height: 12),
            Text('Reminder: ${appState.data.reminderDays} day(s) before. You can change this in Reminders.',
                style: const TextStyle(color: kMuted, fontSize: 13)),
            const SizedBox(height: 16),
            bigButton(_saving ? 'Saving...' : (d.isEdit ? 'Save changes' : 'Save subscription'), _saving ? null : _save),
            if (_fromScan) ...[
              const SizedBox(height: 10),
              bigButton('Try another screenshot', () => Navigator.of(context).pop(), outlined: true),
            ],
          ],
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------ Details
class DetailScreen extends StatelessWidget {
  final String id;
  const DetailScreen({super.key, required this.id});

  Widget _kv(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(k, style: const TextStyle(color: kMuted, fontSize: 15)),
          const SizedBox(width: 16),
          Flexible(child: Text(v, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
        ],
      ),
    );
  }

  String _dateLine(String iso, DateTime today) {
    final d = parseIso(iso);
    if (d == null) return '-';
    return '${fmtDate(d)} (${relDays(daysBetween(today, d))})';
  }

  String _reminderText(Sub s) {
    if (s.cancelled) return 'Off (cancelled)';
    if (!appState.data.notifications) return 'Notifications are off';
    final r = reminderFor(s, appState.data.reminderDays, DateTime.now());
    if (r.status == 'scheduled' && r.at != null) {
      return 'Set for ${fmtDate(r.at!)}, 9:00 AM';
    }
    if (r.status == 'due' && r.daysLeft != null) {
      return 'Reminder time passed. Date is ${relDays(r.daysLeft!)}.';
    }
    return 'No upcoming date';
  }

  Future<void> _search(BuildContext context, Sub s) async {
    final uri = Uri.https('www.google.com', '/search', {'q': 'how to cancel ${s.service} subscription'});
    var ok = false;
    try {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      ok = false;
    }
    if (!ok && context.mounted) showMsg(context, 'Could not open the browser.');
  }

  Future<void> _cancel(BuildContext context, Sub s) async {
    final ok = await confirmDialog(context,
        title: 'Mark as cancelled?',
        text: 'PING will stop reminding you about ${s.service}. This does not cancel it with the service. Cancel there yourself.',
        ok: 'Mark as cancelled');
    if (!ok) return;
    s.cancelled = true;
    await appState.save();
    await notifier.sync();
    if (context.mounted) showMsg(context, 'Marked as cancelled. Reminders are off.');
  }

  Future<void> _delete(BuildContext context, Sub s) async {
    final nav = Navigator.of(context);
    final ok = await confirmDialog(context,
        title: 'Delete subscription?', text: 'This removes ${s.service} from PING. It cannot be undone.', ok: 'Delete', danger: true);
    if (!ok) return;
    await appState.deleteSub(s.id);
    await notifier.sync();
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) {
        final s = appState.byId(id);
        if (s == null) {
          return Scaffold(appBar: AppBar(), body: const Center(child: Text('This subscription was removed.')));
        }
        final today = startOfDay(DateTime.now());
        final status = statusOf(s, today);
        return Scaffold(
          appBar: AppBar(title: Text(s.service, style: const TextStyle(fontWeight: FontWeight.w800))),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
              children: [
                Row(
                  children: [
                    StatusBadge(status: status),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                          color: s.type == 'trial' ? kWarnBg : kPrimaryLight, borderRadius: BorderRadius.circular(20)),
                      child: Text(s.type == 'trial' ? 'Free trial' : 'Subscription',
                          style: TextStyle(
                              color: s.type == 'trial' ? kWarn : kPrimaryDark, fontSize: 12, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Panel(
                  child: Column(
                    children: [
                      _kv('Plan', s.plan.isEmpty ? '-' : s.plan),
                      _kv('Price', s.price.isEmpty ? '-' : s.price),
                      _kv('Trial ends', _dateLine(s.trialEnd, today)),
                      _kv('Renews on', _dateLine(s.renewalDate, today)),
                      _kv('Reminder', _reminderText(s)),
                      _kv('Added', s.source == 'screenshot' ? 'From a screenshot' : 'Manually'),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('How to cancel', style: TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      const Text('PING cannot cancel subscriptions for you. Cancel on the service itself:',
                          style: TextStyle(color: kMuted, fontSize: 14)),
                      const SizedBox(height: 8),
                      ...List<Widget>.generate(
                        cancelSteps.length,
                        (i) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Text('${i + 1}. ${cancelSteps[i]}', style: const TextStyle(color: kMuted, fontSize: 14)),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                bigButton('Search how to cancel', () => _search(context, s)),
                const SizedBox(height: 10),
                bigButton(
                  'Edit details',
                  () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => ReviewScreen(draft: Draft.fromSub(s)))),
                  outlined: true,
                ),
                if (!s.cancelled) ...[
                  const SizedBox(height: 10),
                  bigButton('Mark as cancelled', () => _cancel(context, s), outlined: true),
                ],
                const SizedBox(height: 10),
                bigButton('Delete subscription', () => _delete(context, s), outlined: true, danger: true),
              ],
            ),
          ),
        );
      },
    );
  }
}
